<script>
        $(document).ready (function () {
            $('.print').click (function () {
                window.print ();
            })
        })
</script>

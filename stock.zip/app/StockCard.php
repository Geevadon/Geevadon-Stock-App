<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockCard extends Model
{
    protected $guarded = [];
    protected $table = 'stock_card';
}

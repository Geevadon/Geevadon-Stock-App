<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-3">
        <h1 class="h3 mb-0 text-gray-800">Gestion de Commandes</h1>
        <a href="<?php echo e(route ('orders.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-list fa-sm text-white-50"></i> Liste de Commandes</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-info"></i> Détails - <?php echo e($order->order_number); ?></h6>
        </div>
        <div class="card-body">
            <ul class="list-group">
                <li class="list-group-item">Numéro de la commande : <b><?php echo e($order->order_number); ?></b></li>
                <li class="list-group-item">Date de la commande : <b><?php echo e(date_format (date_create ($order->added_date), 'd/m/Y')); ?></b></li>
                <li class="list-group-item">Nom du client : <b><?php echo e($order->customer_name); ?></b></li>
                <li class="list-group-item">Sous-total : <b><?php echo e(number_format ($order->sub_total, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">TVA (16%) : <b><?php echo e(number_format ($order->tva, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Remise : <b><?php echo e(number_format ($order->discount, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Main d'oeuvre : <b><?php echo e(number_format ($order->workforce, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Montant net : <b><?php echo e(number_format ($order->net_total, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Montant payé : <b><?php echo e(number_format ($order->paid, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Montant dû : <b><?php echo e(number_format ($order->due, 2, ',', '.'). ' $'); ?></b></li>
                <li class="list-group-item">Montant dû en lettres : <b><?php echo e($order->amount_in_letters. ' dollars américains'); ?></b></li>
                <li class="list-group-item">Devise : <b><?php echo e($order->currency); ?></b></li>
                <li class="list-group-item">Type de paiement : <b><?php echo e($order->payment_type); ?></b></li>
                <li class="list-group-item">Statut : <b><?php echo e($order->status == 'not_paid' ? 'Non payé' : 'Payé'); ?></b></li>
                <li class="list-group-item">Désignation : <b><?php echo e($order->designation); ?></b></li>
                <li class="list-group-item">
                    <?php echo e($order->order_details->count () > 1 ? Str::plural ('Produit') : 'Produit'); ?> :
                    <ul>
                        <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><b><?php echo e($detail->product_name); ?> </b> <?php echo e(' (Quantité : '.$detail->product_quantity. ')'); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
              </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/orders/show.blade.php ENDPATH**/ ?>
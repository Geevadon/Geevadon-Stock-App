<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-5">

    <!-- 404 Error Text -->
    <div class="text-center">
      <div class="error mx-auto" data-text="404">404</div>
      <p class="lead text-gray-800 mb-5">Page Introuvable</p>
      <p class="text-gray-500 mb-0">Il semblerait que la page à laquelle vous souhaitez accéder n'existe pas...</p>
      <a href="<?php echo e(route ('page.dashboard')); ?>">&larr; Revenir au Tableau de bord</a>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/errors/404.blade.php ENDPATH**/ ?>
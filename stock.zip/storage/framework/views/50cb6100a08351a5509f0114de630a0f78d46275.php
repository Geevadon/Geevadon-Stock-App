<!DOCTYPE html>
<html lang="<?php echo e(config ('app.locale')); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config ('app.name')); ?></title>
    <link href="<?php echo e(asset ('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/sb-admin-2.css')); ?>" rel="stylesheet">
</head>
<body>
      <div class="container mt-5">
           <div class="row">
               <div class="col-md-12 mx-auto">
                    <?php echo $__env->yieldContent('content'); ?>
               </div>
           </div>
      </div>
</body>
</html>
<?php /**PATH E:\laragon\www\stock\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
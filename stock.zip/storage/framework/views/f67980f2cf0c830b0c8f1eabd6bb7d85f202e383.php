<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10 text-left">
        <h2><i class="fa fa-file-invoice-dollar"></i>&nbsp; Fiche de Stock de <?php echo e($product->product_name); ?> (en valeur)</h2>
    </div>
    <div class="col-md-2 text-right align-self-center to-hide">
        <h6><a href="<?php echo e(route ('products.index')); ?>"><i class="fa fa-arrow-left"></i> Liste de Produits</a></h6>
    </div>
</div>

<table class="table table-bordered mt-3" id="manage_stock">
    <thead>
        <tr>
            <th scope="col">Date</th>
            <th scope="col">Libellé</th>
            <th scope="col">Entrée</th>
            <th scope="col">Sortie</th>
            <th scope="col">Solde</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $a = [];
        $b = [];
        $sumA = 0;
        $sumB = 0;
        ?>

        <?php $__currentLoopData = $stock_cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(date_format(date_create($stock_card->created_at), "d/m/Y")); ?></td>
                <td><?php echo e($stock_card->status == 'out' ? 'Sortie en Stock' : 'Entrée en Stock'); ?></td>
                <td>
                    <?php echo e($stock_card->status != 'out' ? $stock_card->product_price * $stock_card->product_quantity : '-'); ?>

                    <?php

                        if ($stock_card->status == 'in' || $stock_card->status == 'in_approv') {
                            array_push($a, $stock_card->product_price * $stock_card->product_quantity);
                            $sumA = array_sum ($a);
                        }else if ($stock_card->status == 'out') {
                            array_push($b, $stock_card->product_price * $stock_card->product_quantity);
                            $sumB = array_sum ($b);
                        }
                    ?>

                </td>
                <td><?php echo e($stock_card->status == 'out' ? $stock_card->product_price * $stock_card->product_quantity : '-'); ?></td>
                <td><?php echo e($sumA - $sumB); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<div class="text-right">
    <button type="button" class="btn btn-primary mt-2 print"><i class="fa fa-print"></i>&nbsp; Imprimer</button>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/products/stock-card-value.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-3">
    <h1 class="h3 mb-0 text-gray-800">Gestion de Commandes</h1>
    <a href="<?php echo e(route ('orders.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-list fa-sm text-white-50"></i> Liste de Commandes</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-plus"></i> Nouvelle Commande</h6>
    </div>
    <div class="card-body">

        <form method="POST" action="<?php echo e(route ('orders.store')); ?>" novalidate>
            <div class="form-row">
                <div class="col-md-6 px-3">

                    

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_added_date" class="col-md-5 col-form-label col-form-label">Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php $__errorArgs = ['order_added_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_added_date" name="order_added_date" value="<?php echo e(old ('order_added_date') ?: date ('Y-m-d')); ?>" required>

                        <?php $__errorArgs = ['order_added_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_customer_name" class="col-md-5 col-form-label col-form-label">Nom(s) du client <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['order_customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_customer_name" name="order_customer_name" value="<?php echo e(old ('order_customer_name')); ?>" autofocus required>

                        <?php $__errorArgs = ['order_customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="order_product" class="col-md-5">Produit(s) <span class="text-danger">*</span></label>
                        <div class="col-md-7 border border-muted rounded <?php $__errorArgs = ['order_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="max-height: 230px; overflow: scroll;">

                            <ul class="list-group list-group-flush list-group-item-action">

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item list-group-item-action">
                                        <input type="checkbox" class="form-check-input" value="<?php echo e($product->id); ?>" id="order_product_<?php echo e($product->id); ?>" name="order_product[]" <?php echo e(old ('order_product') != null && in_array ($product->id, old ('order_product')) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="order_product_<?php echo e($product->id); ?>">
                                            <?php echo e($product->name); ?>

                                        </label>
                                        <input type="number" class="form-control form-control-sm <?php $__errorArgs = ['order_product_quantity_'.$product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Quantité..." name="order_product_quantity_<?php echo e($product->id); ?>" value="<?php echo e(old ('order_product_quantity_'.$product->id) ?: 1); ?>">
                                    </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>

                        </div>

                        <?php $__errorArgs = ['order_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <div class="invalid-feedback text-danger text-right" role="alert">
                                <b><?php echo e($message); ?></b>
                            </div>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $__errorArgs = ['order_product_quantity_'. $product->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback text-danger text-right" role="alert">
                                    <b><?php echo e($message); ?></b>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

                <div class="col-md-6 px-3">

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_discount" class="col-md-5 col-form-label col-form-label">Remise</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['order_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_discount" name="order_discount" value="<?php echo e(old ('order_discount')); ?>">

                        <?php $__errorArgs = ['order_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_workforce" class="col-md-5 col-form-label col-form-label">Main d'oeuvre</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['order_workforce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_workforce" name="order_workforce" value="<?php echo e(old ('order_workforce')); ?>">

                        <?php $__errorArgs = ['order_workforce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_paid" class="col-md-5 col-form-label col-form-label">Montant payé</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['order_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_paid" name="order_paid" value="<?php echo e(old ('order_paid')); ?>">

                        <?php $__errorArgs = ['order_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_payment_type" class="col-md-5 col-form-label col-form-label">Moyen de paiement <span class="text-danger">*</span></label>
                        <select class="form-control <?php $__errorArgs = ['order_payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_payment_type" name="order_payment_type" required>
                            <option value="Cash" <?php echo e(old ('order_payment_type') == 'Cash' ? 'selected' : ''); ?>>Cash</option>
                            <option value="Carte" <?php echo e(old ('order_payment_type') == 'Carte' ? 'selected' : ''); ?>>Carte</option>
                            <option value="Chèque" <?php echo e(old ('order_payment_type') == 'Chèque' ? 'selected' : ''); ?>>Chèque</option>
                        </select>

                        <?php $__errorArgs = ['order_payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_currency" class="col-md-5 col-form-label col-form-label">Devise <span class="text-danger">*</span></label>
                        <select class="form-control <?php $__errorArgs = ['order_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_currency" name="order_currency" required>
                            <option value="USD" <?php echo e(old ('order_currency') == 'USD' ? 'selected' : ''); ?>>USD</option>
                            <option value="CDF" <?php echo e(old ('order_currency') == 'CDF' ? 'selected' : ''); ?>>CDF</option>
                            <option value="EUR" <?php echo e(old ('order_currency') == 'EUR' ? 'selected' : ''); ?>>EUR</option>
                        </select>

                        <?php $__errorArgs = ['order_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <?php echo csrf_field(); ?>
                        <label for="order_designation" class="col-md-5 col-form-label col-form-label">Désignation <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['order_designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-7" id="order_designation" name="order_designation" cols="30" rows="2" required><?php echo e(old ('order_designation')); ?></textarea>

                        <?php $__errorArgs = ['order_designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-danger text-right" role="alert">
                            <b><?php echo e($message); ?></b>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-check"></i> Valider la Commande</button>
        </form>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/orders/create.blade.php ENDPATH**/ ?>
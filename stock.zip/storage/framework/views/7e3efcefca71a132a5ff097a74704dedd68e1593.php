<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-3">
        <h1 class="h3 mb-0 text-gray-800">Mot-clé : <?php echo e($query ?: 'aucun'); ?></h1>
        <a href="<?php echo e(route ('products.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-list fa-sm text-white-50"></i> Tous les Produits</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-list"></i> Résultat(s) de la recherche</h6>
        </div>
        <div class="card-body">
            <?php if($products == null): ?>
                <h5>Aucun résultat pour votre recherche...</h5>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped text-nowrap" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nom</th>
                                <th>Date</th>
                                <th>Catégorie</th>
                                <th>Marque</th>
                                <th>Prix</th>
                                <th>Quantité</th>
                                <th>Alerte</th>
                                <th>Statut</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $n = 0 ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$n); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e(date_format (date_create ($product->added_date), 'd/m/Y')); ?></td>
                                    <td><?php echo e($product->category->name); ?></td>
                                    <td><?php echo e($product->brand->name); ?></td>
                                    <td><?php echo e(number_format ($product->price, 2, ',', '.'). ' $'); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td><?php echo e($product->alert); ?></td>
                                    <td><?php echo $product->status == 'not_sufficient' ? "<span class='text-danger font-weight-bold'>Critique</span>" : "<span class='text-success font-weight-bold'>Suffisant</span>"; ?></td>
                                    <td>
                                        <div class="dropleft">
                                            <button class="btn btn-primary dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Actions
                                            </button>
                                            <div class="dropdown-menu border border-dark" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item" href="<?php echo e(route ('products.edit', $product->id)); ?>"><i class="fa fa-edit"></i> Editer</a>

                                                <div class="dropdown-divider"></div>

                                                <a class="dropdown-item" href="<?php echo e(route ('products.stock.supply.edit', $product->id)); ?>"><i class="fa fa-plus"></i> Approvisionner</a>

                                                <div class="dropdown-divider"></div>

                                                <form action="<?php echo e(route ('products.destroy', $product->id)); ?>" method="POST" id="delete-form-<?php echo e($product->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item delete" did="<?php echo e($product->id); ?>">
                                                        <i class="fa fa-trash"></i> Supprimer
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/search/search.blade.php ENDPATH**/ ?>
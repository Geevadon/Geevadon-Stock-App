<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-3">
        <h1 class="h3 mb-0 text-gray-800">Paiement de la Commande</h1>
        <a href="<?php echo e(route ('orders.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-list fa-sm text-white-50"></i> Liste de Commandes</a>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-edit"></i> Paiement de #<?php echo e($order->order_number); ?></h6>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route ('orders.payment.update', $order->id)); ?>" novalidate>
                <div class="form-row">
                    <div class="col-md-10 mx-auto">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="form-group">
                            <input type="text" class="form-control" id="order_customer_name" name="order_customer_name" value="<?php echo e('Client : '. $order->customer_name); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="order_due" name="order_due" value="<?php echo e('Dette : '. number_format ($order->due, 2, ',', '.'). ' $'); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control <?php $__errorArgs = ['order_payment_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="order_payment_amount" name="order_payment_amount" placeholder="Tapez le montant payé..." value="<?php echo e(old ('order_payment_amount')); ?>" required>

                            <?php $__errorArgs = ['order_payment_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback text-danger" role="alert">
                                    <b><?php echo e($message); ?></b>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fa fa-check"></i> Valider
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\stock\resources\views/payment/index.blade.php ENDPATH**/ ?>